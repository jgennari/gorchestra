import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cn6kALDM.js";import"./chunk-I66GZJ75-B5Kqwsoo.js";import"./chunk-NSK5VX7P-D-2s9kxO.js";import"./chunk-4I5QYGJK-DrUIBhdn.js";import"./chunk-WRU74C26-BTrdnvFm.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-jHJSYUdJ.js";import"./chunk-2GRJ4B5K-CKhXluw0.js";import"./chunk-XXDRQBXY-Y1lmGfHA.js";import"./chunk-KBJHAD2P-B6rbQcb8.js";import"./chunk-W5SLKNZC-CWt9MxzY.js";import"./chunk-QR6OTTB3-DgHf9OSY.js";import"./chunk-7Z6QIM7H-BK_SfjB7.js";import"./chunk-J7OUQ5F2-346EK4vE.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-Dcn46tmo.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};
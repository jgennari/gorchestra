import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cn6kALDM.js";import"./chunk-I66GZJ75-B8eB8U-Q.js";import"./chunk-NSK5VX7P-Dg50fDrM.js";import"./chunk-4I5QYGJK-kvn2GFO8.js";import"./chunk-WRU74C26-DpymfJCV.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-Bywme5Vl.js";import"./chunk-2GRJ4B5K-QinhEiH-.js";import"./chunk-XXDRQBXY-Y1lmGfHA.js";import"./chunk-KBJHAD2P-Cqj-ZIdh.js";import"./chunk-W5SLKNZC-c0Ml3s7b.js";import"./chunk-QR6OTTB3-GpxV5vhi.js";import"./chunk-7Z6QIM7H-DMfYLN3X.js";import"./chunk-J7OUQ5F2-OWTXyf6l.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-CpzIXD3Z.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};
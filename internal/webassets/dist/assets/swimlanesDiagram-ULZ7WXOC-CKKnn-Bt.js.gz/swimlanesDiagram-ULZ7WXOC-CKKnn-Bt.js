import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cn6kALDM.js";import"./chunk-I66GZJ75-DMEbTf6F.js";import"./chunk-NSK5VX7P-Djdm43-g.js";import"./chunk-4I5QYGJK-DwoF2hQy.js";import"./chunk-WRU74C26-B8yT4DSz.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-Beel_sSi.js";import"./chunk-2GRJ4B5K-EnpFqgTa.js";import"./chunk-XXDRQBXY-Y1lmGfHA.js";import"./chunk-KBJHAD2P-Pw69WD1b.js";import"./chunk-W5SLKNZC-CHD3QCBf.js";import"./chunk-QR6OTTB3-DW3V2hgK.js";import"./chunk-7Z6QIM7H-BjyfIKn2.js";import"./chunk-J7OUQ5F2-BvYHQWIS.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-Ccd3H7i1.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};
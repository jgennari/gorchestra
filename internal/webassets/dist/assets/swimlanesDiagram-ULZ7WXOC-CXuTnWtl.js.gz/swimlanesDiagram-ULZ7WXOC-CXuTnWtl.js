import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cn6kALDM.js";import"./chunk-I66GZJ75-DJTNDre5.js";import"./chunk-NSK5VX7P-De9BuCAu.js";import"./chunk-4I5QYGJK-CRbR198D.js";import"./chunk-WRU74C26-ef021aUB.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-CHx0tlkG.js";import"./chunk-2GRJ4B5K-fbztnRmX.js";import"./chunk-XXDRQBXY-Y1lmGfHA.js";import"./chunk-KBJHAD2P--D3hGw7K.js";import"./chunk-W5SLKNZC-5WzwUEiu.js";import"./chunk-QR6OTTB3-Biy0Qno5.js";import"./chunk-7Z6QIM7H-BqT9exQ9.js";import"./chunk-J7OUQ5F2-BZDtrw1n.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-DKk_Bezq.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};
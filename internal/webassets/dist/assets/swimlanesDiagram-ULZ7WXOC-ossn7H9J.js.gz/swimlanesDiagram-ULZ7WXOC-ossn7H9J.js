import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-BBG2aZui.js";import"./chunk-I66GZJ75-BbD353eM.js";import"./chunk-NSK5VX7P-NBykVoh-.js";import"./chunk-4I5QYGJK-44_a5f54.js";import"./chunk-WRU74C26-DlecOpn6.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-BuX8ppfL.js";import"./chunk-2GRJ4B5K-DGvH6A_V.js";import"./chunk-XXDRQBXY-DCFzsPgJ.js";import"./chunk-KBJHAD2P-CWmfZYg2.js";import"./chunk-W5SLKNZC-DeWYbmUn.js";import"./chunk-QR6OTTB3-DeXq5xuq.js";import"./chunk-7Z6QIM7H-BjJug6Bu.js";import"./chunk-J7OUQ5F2-C8gETrXS.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-BdPfnlkT.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};
import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cn6kALDM.js";import"./chunk-I66GZJ75-D8WN76JU.js";import"./chunk-NSK5VX7P-vzoq_Xn1.js";import"./chunk-4I5QYGJK-DPocfDt6.js";import"./chunk-WRU74C26-BQza2ZgQ.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-BbnrwvuH.js";import"./chunk-2GRJ4B5K-B92ThkUy.js";import"./chunk-XXDRQBXY-Y1lmGfHA.js";import"./chunk-KBJHAD2P-CyIBNYjE.js";import"./chunk-W5SLKNZC-BhgHMwLr.js";import"./chunk-QR6OTTB3-kpaPvXEn.js";import"./chunk-7Z6QIM7H-Ck1KiEVX.js";import"./chunk-J7OUQ5F2-CQEjlJcL.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-Dah4sa68.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};
import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cn6kALDM.js";import"./chunk-I66GZJ75-DjFuTK50.js";import"./chunk-NSK5VX7P-Db6pS3lF.js";import"./chunk-4I5QYGJK-DRnXG8LS.js";import"./chunk-WRU74C26-CTBxN2gD.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-ChmDIwq7.js";import"./chunk-2GRJ4B5K-DyLTN3KU.js";import"./chunk-XXDRQBXY-Y1lmGfHA.js";import"./chunk-KBJHAD2P-Cq_xsjrD.js";import"./chunk-W5SLKNZC-GVtw9dvs.js";import"./chunk-QR6OTTB3-BMjX3Hxq.js";import"./chunk-7Z6QIM7H-4qZ2Sy4Y.js";import"./chunk-J7OUQ5F2-Df3JLGlF.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-CAM6hywl.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};
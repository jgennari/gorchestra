import{n as e}from"./chunk-Y2CYZVJY-DsF7k-Jl.js";import"./src-Cn6kALDM.js";import"./chunk-I66GZJ75-fI7Sqe4V.js";import"./chunk-NSK5VX7P-DMYZL8qQ.js";import"./chunk-4I5QYGJK-qgejalow.js";import"./chunk-WRU74C26-DZmy5LXB.js";import"./chunk-7BUUIJ7U-Bb538aSH.js";import"./chunk-UBXNYLIW-BSuG88wO.js";import"./chunk-2GRJ4B5K-CrqMLeGs.js";import"./chunk-XXDRQBXY-Y1lmGfHA.js";import"./chunk-KBJHAD2P-CR_6PdMk.js";import"./chunk-W5SLKNZC-CvtrROxm.js";import"./chunk-QR6OTTB3-ChAlJWMQ.js";import"./chunk-7Z6QIM7H-DFAFTB7U.js";import"./chunk-J7OUQ5F2-crh_PzSv.js";import"./chunk-ZIRB5QZD-H-kepumB.js";import{r as t,t as n}from"./chunk-JQJVKLGR-CbPb6MQr.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};